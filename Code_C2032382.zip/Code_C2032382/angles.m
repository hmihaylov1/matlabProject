function angles
%ANGLES Summary of this function goes here
%   Detailed explanation goes here
    %Import the data
    V = importdata("saveshape.txt");
    x_vals = V(:,1);
    y_vals = V(:,2);
    %calculate the angles
    Z = [V(end,:); V; V(1,:)];
    for k = 2:size(Z,1)-1
        %angles in radians
        a_radians(:,k-1) = [(atan2(Z(k-1,2)-Z(k,2), Z(k-1,1)-Z(k,1))); (atan2(Z(k+1,2)-Z(k,2), Z(k+1,1)-Z(k,1)))];
        %angles in degrees
        crdnt_angle(k-1) = mod(360 - diff(rad2deg(a_radians(:,k-1))),360);
    end


    axis('equal')
    hold on
    pgon = polyshape(x_vals,y_vals);
    plot(pgon,'LineWidth',2,'FaceAlpha',0);
    
    for ii = 2:size(Z,1)-1
        scatter(Z(ii,1),Z(ii,2),30,crdnt_angle(ii -1),'filled');
        %plot the colormap
        colorbar;
        text(x_vals, y_vals, compose('\v\v\t%.1f°',crdnt_angle));
        colormap('jet');
        caxis([0, 360]);
        %disp(Map);
    end
    
    hold off
end