function [] = save_function()
%SAVE Summary of this function goes here
%   Detailed explanation goes here

%find the drawn polygon
ax = gca;
drawn_poly = findobj(gca, 'Type', 'images.roi.Polygon');
coordinates = drawn_poly.Position;

disp(coordinates);

%save the drawn polygon to the text file
save("saveshape.txt","coordinates",'-ascii');


end

