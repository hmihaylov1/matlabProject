function MBR1
    % Importing data
    poly_vertices = importdata('saveshape.txt');
    
    % Splitting X and Y Data
    x = poly_vertices(:,1);
    y = poly_vertices(:,2);
    
    % Determines direction of how the coordinates are loaded in i.e
    % clockwise or anti-clockwise.
    direction = ispolycw(x,y);
    
    % Creates the polygon with coordinates passed in.
    pgon = polyshape(x,y);
    
    % Calculating the angle of each vertex.
    Z = [poly_vertices(end,:); poly_vertices; poly_vertices(1,:)];
    a_radians = zeros(2,size(Z,1)-2);
    crdnt_angle = zeros(1,size(Z,1)-2);
    for k = 2:size(Z,1)-1
        a_radians(:,k-1) = [(atan2(Z(k-1,2)-Z(k,2), Z(k-1,1)-Z(k,1))); (atan2(Z(k+1,2)-Z(k,2), Z(k+1,1)-Z(k,1)))];
        % Depending on the direction if it is clockwise or anti-clockwise
        % different calculations are run to find the angles.
        if direction
            crdnt_angle(k-1) = mod(diff(rad2deg(a_radians(:,k-1))),360);
        else  
            crdnt_angle(k-1) = mod(360 - diff(rad2deg(a_radians(:,k-1))),360);
        end
        
    end
    
    % Finds the length and width of the polygon 
    [L, R] = boundingbox(pgon);
    
    % Calculates the MBR's middle Point
    length_a = L(1) + L(2);
    length_b = R(1) + R(2); 
    Xm = length_a/2;
    Ym = length_b/2;
    
    % Calculates radius for the two circles
    c1r = (L(2) - L(1)) / 2;
    c2r = (R(2) - R(1)) / 2;
    
    % Plots the two circles
    viscircles([Xm Ym],c1r,'Color','g');
    viscircles([Xm Ym],c2r,'Color','r');
    
    %Circles center point (xc,yx)
    [xc,yc]=deal(Xm,Ym); 
    
    % Aproximating the circles as a polygon for the function linexline2d() to work.    
    circle1 = nsidedpoly(100000, 'Center', [xc yc], 'Radius', c1r);
    circle2 = nsidedpoly(100000, 'Center', [xc yc], 'Radius', c2r);
    
    % Creates a new list of the vertices which addes the first vertex to the end of the list. 
    poly_vertices=pgon.Vertices;
    num=size(poly_vertices,1);
    poly_vertices=poly_vertices([1:num,1],:);
    
    axis('equal')
    hold on
    % Plots the polygon and the minimum bound rectangle(MBR).
    plot(pgon,'FaceAlpha',0,'LineWidth',2);
    rectangle('Position',[L(1) R(1) (L(2) - L(1)) (R(2) - R(1))], 'EdgeColor','c')
    plot(Xm,Ym,'ro');

    for i=1:num
        % Finds the intersections between the polygon and the circles and
        % plots a star at those points.
        poly_ver1 = poly_vertices(i,:);
        poly_ver2 = poly_vertices(i+1,:);
        circle1_intersections=linexlines2D(circle1, poly_ver1, poly_ver2);
        plot(circle1_intersections(1,:), circle1_intersections(2,:), '*k', 'MarkerSize', 10, "LineWidth",1);
        circle2_intersections=linexlines2D(circle2, poly_ver1, poly_ver2);
        plot(circle2_intersections(1,:), circle2_intersections(2,:), '*k', 'MarkerSize', 10, "LineWidth",1);
        
        % Sanity checks to remove empty double vectors.
        if (isempty(circle2_intersections(1,:)) || isempty(circle1_intersections(1,:)))
            [circle1_x, circle1_y, circle2_x, circle2_y] = deal(NaN, NaN, NaN, NaN);
        else
            [circle1_x, circle1_y] = deal(circle1_intersections(1,1), circle1_intersections(2,1));
            [circle2_x, circle2_y] = deal(circle2_intersections(1,1), circle2_intersections(2,1));
        end

        % Plots the first line segment at zero degrees.
        plot([circle1_x circle2_x], [circle1_y circle2_y],'m','LineWidth',2)
        
        % Creating a matrix of the points so matrix multiplication can be
        % carried out.
        matrix_of_points = [[circle1_x circle2_x];[circle1_y circle2_y]];      
        center = repmat([xc; yc], 1, length(matrix_of_points(1,:)));
        
        % Performing matrix multiplication using the points of the first
        % line segment and the center point of the circles (xc, yc).
        % Code used here was found in the link below.
        % https://uk.mathworks.com/matlabcentral/answers/93554-how-can-i-rotate-a-set-of-points-in-a-plane-by-a-certain-angle-about-an-arbitrary-point
        for a = 3:3:15
            theta = (-a * pi) / 180;  % theta is the angle in degrees.
            R = [cos(theta) -sin(theta); sin(theta) cos(theta)];
            
            % Performs matrix multiplication
            s = matrix_of_points - center;
            so = R*s;
            vo = so + center;
            
            % Rotates the line segment based on the angles sepcified above.
            x_rotated = vo(1,:);
            y_rotated = vo(2,:);

            % Plots the line segments.
            plot(matrix_of_points(1,:), matrix_of_points(2,:), 'k-', x_rotated, y_rotated, 'm-');
            plot(matrix_of_points(1,:), matrix_of_points(2,:), 'k-', x_rotated, y_rotated, 'm*');
        end


    end
    text(x, y, compose('\v\v\t%.1f°',crdnt_angle));
    hold off
end