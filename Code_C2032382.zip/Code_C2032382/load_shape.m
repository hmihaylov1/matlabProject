function [] = load_shape()
%LOAD_SHAPE Summary of this function goes here
%   Detailed explanation goes here

%Import the data
Saved = importdata('saveshape.txt');
disp(Saved);

%access the columns
x = Saved(:, 1);
y = Saved(:, 2);

disp(x);
 disp(y);

 A = polyshape(x,y);
disp(A);
plot(polyshape(x,y));
end

