function [outputArg1, outputArg2] = drawpolyfunc(inputArg1, inputArg2)

outputArg1 = inputArg1;
outputArg2 = inputArg2;

%Plot the polygon
h = drawpolygon("Color",'blue','InteractionsAllowed','none');
h.FaceAlpha = 0;
h.FaceSelectable = true;


end
